package TicketBooking;
import java.util.*;
public class taxi extends Thread {

	int id;
	char currentPoint ='A';
	double totalearn =0.0;
	boolean isFree = true;
	
	ArrayList<Integer> bookingid = new ArrayList<Integer>();
	ArrayList<Character> costid = new ArrayList<Character>();
	ArrayList<Character> from = new ArrayList<Character>();
	ArrayList<Character> to = new ArrayList<Character>();
	ArrayList<Integer> pickUpTime = new ArrayList<Integer>();
	ArrayList<Integer> dropTime = new ArrayList<Integer>();
	ArrayList<Double> amount = new ArrayList<Double>();
	
	taxi(int id)
	{
		this.id=id;
	}
	
	void assign(int bookid,char cid,char pp,char dp,int pt)
	{
		bookingid.add(bookid);
		costid.add(cid);
		from.add(pp);
		to.add(dp);
		pickUpTime.add(pt);
		dropTime.add(pp+Math.abs(pp-dp));
	    amount.add((double)(100+((15*Math.abs(pp-dp))-5)*10));
		totalearn+=(double)(100+((15*Math.abs(pp-dp))-5)*10);
		System.out.print("Amount to Pay : "+(double)(100+((15*Math.abs(pp-dp))-5)*10));
		this.currentPoint=dp;
	}
}
