class taxiHold extends Thread{
	taxi t;
	taxiHold(taxi t){
		this.t=t;
	}
	public void run(){
		t.isFree=false;
		try{
			System.out.println("Taxi id "+t.id+" is Assigned ");
			Thread.sleep(60000);
			t.isFree=true;
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}