package TicketBooking;
import java.util.*;
class taxiBook extends Thread{
	static Scanner scan = new Scanner(System.in);
	static int bookid = 1;
	static ArrayList<taxi> taxies = new ArrayList<taxi>();
	taxiBook(){
		for(int i=1;i<=4;i++){//work with four taxies(i=1 to i=4),you can do n no of taxi
			taxi t = new taxi(i);
			taxies.add(t);
		}
		/* for(int i=0;i<4;i++){//i start with zero
			 System.out.println(taxies.get(i).id);
		}
		*/
	}
	  
	private void getDetials()
	{
		System.out.println("------Taxi Booking-------");
		System.out.println("1.Book Taxi ");
		System.out.println("2.Taxi Detials ");
		System.out.println("3.Taxi Status ");
		System.out.println("4.Exit ");
		System.out.println("Enter your Choice: ");
		int ch = sc.nextInt();
		
		switch(ch)
		{
		  case 1:
		  {
			booktaxi();
		  }
		}
	}
	
	private void booktaxi()
	{
		System.out.print("Enter Customer ID: ");
	    char cid = sc.next().charAt(0);
	    System.out.print("Enter Pickup Point :");
	    char pp = sc.next().charAt(0);
	    System.out.print("Enter Drop Point: ");
	    char dp = sc.next().charAt(0);
	    System.out.print("�nter PickUp Time");
	    int pt = sc.nextInt();
	    
	    
	    for(taxi t :taxies)
	    {
	    	if(t.isFree==true && t.currentPoint==pp )
	    	{
	    		t.assign(bookid, cid, pp, dp, pt);
	    		bookid++;
	    		
	    	}
	    }
	}
	

	public static void main(String args[]){
		taxiBook tb = new taxiBook();
		tb.getDetails();
	}
}